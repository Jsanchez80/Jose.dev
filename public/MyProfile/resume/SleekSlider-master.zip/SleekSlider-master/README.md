SleekSlider
===========

A full width jQuery slider with pagination, tabs, and previous/next button navigation. 
